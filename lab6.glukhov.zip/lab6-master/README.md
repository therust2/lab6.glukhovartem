![Alt text](./static/1.png "Begin screen")
<h1>Home screen without last request data</h1><br><br>

![Alt text](./static/2.png "1 task")
<h1>Result of first task</h1><br><br>

![Alt text](./static/3.png "local storage")
<h1>Home screen with last request data</h1><br><br>

![Alt text](./static/4.png "2 task")
<h1>Result of second task</h1><br><br>

![Alt text](./static/5.png "3 task")
<h1>Result of third task</h1><br><br>